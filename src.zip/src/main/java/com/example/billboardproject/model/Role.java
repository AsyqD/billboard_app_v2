package com.example.billboardproject.model;

public enum Role  {
    MANAGER, USER

}
