$(document).ready(function(){
    
    
    $('.cards').slick({
        infinite: true,
        slidesToShow: 3,
        slidesToScroll: 3,
        arrows: false,
        dots: true,
        centerMode: true,
        centerPanding: '40px',
        autoplay: true,
        autoplaySpeed: 5000,
        cssEase: 'ease',
        speed: 800,
        infinite: true
      });


});
