package com.example.billboardproject;

import org.junit.Test;

class BillboardProjectApplicationTests {

    @Test
    void contextLoads() {
    }

}
